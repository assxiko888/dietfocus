-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 18, 2024 at 10:34 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `database_task`
--

-- --------------------------------------------------------

--
-- Table structure for table `dietplans`
--

CREATE TABLE `dietplans` (
  `PlanID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `DayOfWeek` varchar(20) NOT NULL,
  `MealType` varchar(50) NOT NULL,
  `FoodItems` text DEFAULT NULL,
  `Calories` int(11) DEFAULT NULL,
  `Nutrients` varchar(100) DEFAULT NULL,
  `Duration` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dietplans`
--

INSERT INTO `dietplans` (`PlanID`, `UserID`, `DayOfWeek`, `MealType`, `FoodItems`, `Calories`, `Nutrients`, `Duration`) VALUES
(1, 101, 'Monday', 'Breakfast', 'Oatmeal with fruits', 300, 'Carbs, Protein', '2 weeks'),
(2, 101, 'Monday', 'Lunch', 'Grilled Chicken Salad', 400, 'Protein, Vitamins', '2 weeks'),
(3, 101, 'Tuesday', 'Breakfast', 'Greek Yogurt with Berries', 250, 'Protein, Fiber', '2 weeks'),
(4, 101, 'Tuesday', 'Lunch', 'Quinoa with Roasted Vegetables', 350, 'Carbs, Fiber', '2 weeks'),
(5, 101, 'Wednesday', 'Breakfast', 'Whole Wheat Toast with Avocado', 320, 'Healthy Fats, Fiber', '2 weeks'),
(6, 101, 'Monday', 'Breakfast', 'Oatmeal with fruits', 300, 'Carbs, Protein', '1 month'),
(7, 101, 'Monday', 'Lunch', 'Grilled Chicken Salad', 400, 'Protein, Vitamins', '1 month'),
(8, 101, 'Tuesday', 'Breakfast', 'Greek Yogurt with Berries', 250, 'Protein, Fiber', '1 month'),
(9, 101, 'Tuesday', 'Lunch', 'Quinoa with Roasted Vegetables', 350, 'Carbs, Fiber', '1 month'),
(10, 101, 'Wednesday', 'Breakfast', 'Whole Wheat Toast with Avocado', 320, 'Healthy Fats, Fiber', '1 month'),
(11, 101, 'Monday', 'Breakfast', 'Oatmeal with fruits', 300, 'Carbs, Protein', '2 months'),
(12, 101, 'Monday', 'Lunch', 'Grilled Chicken Salad', 400, 'Protein, Vitamins', '2 months'),
(13, 101, 'Tuesday', 'Breakfast', 'Greek Yogurt with Berries', 250, 'Protein, Fiber', '2 months'),
(14, 101, 'Tuesday', 'Lunch', 'Quinoa with Roasted Vegetables', 350, 'Carbs, Fiber', '2 months'),
(15, 101, 'Wednesday', 'Breakfast', 'Whole Wheat Toast with Avocado', 320, 'Healthy Fats, Fiber', '2 months'),
(16, 101, 'Monday', 'Breakfast', 'Oatmeal with fruits', 300, 'Carbs, Protein', '1 month 2 weeks'),
(17, 101, 'Monday', 'Lunch', 'Grilled Chicken Salad', 400, 'Protein, Vitamins', '1 month 2 weeks'),
(18, 101, 'Tuesday', 'Breakfast', 'Greek Yogurt with Berries', 250, 'Protein, Fiber', '1 month 2 weeks'),
(19, 101, 'Tuesday', 'Lunch', 'Quinoa with Roasted Vegetables', 350, 'Carbs, Fiber', '1 month 2 weeks'),
(20, 101, 'Wednesday', 'Breakfast', 'Whole Wheat Toast with Avocado', 320, 'Healthy Fats, Fiber', '1 month 2 weeks'),
(21, 101, 'Monday', 'Breakfast', 'Oatmeal with fruits', 300, 'Carbs, Protein', '3 months'),
(22, 101, 'Monday', 'Lunch', 'Grilled Chicken Salad', 400, 'Protein, Vitamins', '3 months'),
(23, 101, 'Tuesday', 'Breakfast', 'Greek Yogurt with Berries', 250, 'Protein, Fiber', '3 months'),
(24, 101, 'Tuesday', 'Lunch', 'Quinoa with Roasted Vegetables', 350, 'Carbs, Fiber', '3 months'),
(25, 101, 'Wednesday', 'Breakfast', 'Whole Wheat Toast with Avocado', 320, 'Healthy Fats, Fiber', '3 months');

-- --------------------------------------------------------

--
-- Table structure for table `exerciseroutines`
--

CREATE TABLE `exerciseroutines` (
  `RoutineID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `ExerciseType` varchar(100) DEFAULT NULL,
  `Duration` int(11) DEFAULT NULL,
  `IntensityLevel` varchar(50) DEFAULT NULL,
  `CaloriesBurned` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `exerciseroutines`
--

INSERT INTO `exerciseroutines` (`RoutineID`, `UserID`, `ExerciseType`, `Duration`, `IntensityLevel`, `CaloriesBurned`) VALUES
(1, 1, 'Running', 30, 'Medium', 300),
(2, 1, 'Weightlifting', 45, 'High', 200),
(3, 2, 'Cycling', 60, 'Medium', 400),
(4, 2, 'Yoga', 60, 'Low', 150),
(5, 3, 'Swimming', 45, 'High', 500),
(6, 3, 'Walking', 60, 'Low', 200),
(7, 4, 'Running', 45, 'High', 400),
(8, 4, 'Cycling', 30, 'Medium', 250),
(9, 5, 'Weightlifting', 60, 'High', 300),
(10, 5, 'Yoga', 30, 'Low', 100),
(11, 6, 'Running', 30, 'Medium', 300),
(12, 6, 'Weightlifting', 45, 'High', 200),
(13, 7, 'Cycling', 60, 'Medium', 400),
(14, 7, 'Yoga', 60, 'Low', 150),
(15, 8, 'Swimming', 45, 'High', 500),
(16, 8, 'Walking', 60, 'Low', 200),
(17, 9, 'Running', 45, 'High', 400),
(18, 9, 'Cycling', 30, 'Medium', 250),
(19, 10, 'Weightlifting', 60, 'High', 300);

-- --------------------------------------------------------

--
-- Table structure for table `gym`
--

CREATE TABLE `gym` (
  `GymID` int(11) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `City` varchar(100) DEFAULT NULL,
  `Phone` varchar(20) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `MembershipPrice` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gym`
--

INSERT INTO `gym` (`GymID`, `Name`, `Address`, `City`, `Phone`, `Email`, `MembershipPrice`) VALUES
(1, 'Anytime Fitness', '26 Broad St', 'Alexander City, AL', '(256) 329-1004', 'jane.doe@anytimefitness.com (77.3%)', 41),
(2, 'Anytime Fitness', '11971 Liberty Pkwy', 'Birmingham (Liberty Park/Mountain Brook), AL', '(205) 957-2525', 'jane.doe@anytimefitness.com (77.3%)', 24),
(3, 'Anytime Fitness', '1984 Veterans Memorial Dr', 'Birmingham (Adamsville), AL', '(205) 874-6644', 'jane.doe@anytimefitness.com (77.3%)', 32),
(4, 'Anytime Fitness', '1650 Douglas Ave', 'Brewton, AL', '	(251) 314-1411', 'jane.doe@anytimefitness.com (77.3%)', 21),
(5, 'Anytime Fitness', '16054 Hwy. 280 Ste. 700', 'Chelsea, AL', '(205) 678-8820', 'jane.doe@anytimefitness.com (77.3%)', 24.99),
(6, 'Anytime Fitness', '2020 US-98 Ste C', 'Daphne, AL', '(251) 626-5018', 'jane.doe@anytimefitness.com (77.3%)', 23.5),
(7, 'Anytime Fitness', '8936 Lake Otis Pkwy', 'Anchorage, AK', '	(907) 339-2348', 'jane.doe@anytimefitness.com (77.3%)', 41.99),
(8, 'Anytime Fitness', '	42407 N Vision Way', 'Anthem, AZ', '	(623) 215-4669', 'jane.doe@anytimefitness.com (77.3%)', 20.99),
(9, 'Anytime Fitness', '3699 Hwy 95 Suite 660', 'Bullhead City, AZ', '(928) 704-0774', 'jane.doe@anytimefitness.com (77.3%)', 19.99),
(10, 'Anytime Fitness', '1420 S Constitution Ave', 'Ashdown, AR, AZ', '(870) 898-5700', 'jane.doe@anytimefitness.com (77.3%)', 34.79),
(11, 'Anytime Fitness', '883D Island Dr', 'Alameda, CA', '(510) 864-2030', 'jane.doe@anytimefitness.com (77.3%)', 23.99),
(12, 'Anytime Fitness', '177 Craft Dr Ste 102', 'Alamosa, CO', '(719) 589-6520', 'jane.doe@anytimefitness.com (77.3%)', 34),
(13, 'Anytime Fitness', '250 Albany Turnpike', 'Canton, CT', '	860-352-2074', 'jane.doe@anytimefitness.com (77.3%)', 20.99),
(14, 'Anytime Fitness', '235 Governors Pl', 'Bear, DE 19701', '(302) 834-2348', 'jane.doe@anytimefitness.com (77.3%)', 16.99),
(15, 'Anytime Fitness', '15202 NW 147th Dr', 'Alachua, FL', '(386) 518-5277', 'jane.doe@anytimefitness.com (77.3%)', 46),
(16, 'Anytime Fitness', '6110 Hwy 41 N', 'Apollo Beach, FL', '(813) 641-7171', 'jane.doe@anytimefitness.com (77.3%)', 21.99),
(17, 'Anytime Fitness', '1309 East Oak St', 'Arcadia, FL', '(863) 240-0871', 'jane.doe@anytimefitness.com (77.3%)', 20.99),
(18, 'Anytime Fitness', '1727 Mars Hill Rd Ste 13', 'Acworth (Mars Hill Rd), GA', '(770) 421-6000', 'jane.doe@anytimefitness.com (77.3%)', 16.99),
(19, 'Anytime Fitness', '2483 Cedarcrest Rd', 'Acworth (Cedarcrest Rd), GA', '(770) 966-1200', 'jane.doe@anytimefitness.com (77.3%)', 46),
(20, 'Anytime Fitness', '1221 W 4th St', 'Adel, GA', '	(229) 223-3195', 'jane.doe@anytimefitness.com (77.3%)', 21.99),
(21, 'Anytime Fitness', '99-084 Kauhale St', 'Aiea, HI', '(808) 200-1400', 'jane.doe@anytimefitness.com (77.3%)', 45),
(22, 'Anytime Fitness', '747 Queen St.', 'Honolulu, HI', '(808)-744-5300', 'jane.doe@anytimefitness.com (77.3%)', 24),
(23, 'Anytime Fitness', '26 Hoolai St', 'Kailua, HI', '(808) 373-6746', 'jane.doe@anytimefitness.com (77.3%)', 21.99),
(24, 'Anytime Fitness', '1615 S Midway Ave', 'Ammon, ID', '(208) 523-9675', 'jane.doe@anytimefitness.com (77.3%)', 55),
(25, 'Anytime Fitness', '1265 Pkwy Dr', 'Blackfoot, ID', '	(208) 782-2348', 'jane.doe@anytimefitness.com (77.3%)', 46),
(26, 'Anytime Fitness', '474 Orchard St', 'Antioch, IL', '(847) 395-2424', 'jane.doe@anytimefitness.com (77.3%)', 16.99),
(27, 'Anytime Fitness', '205 W Harcourt Rd', 'Angola, IN', '(260) 665-6666', 'jane.doe@anytimefitness.com (77.3%)', 47),
(28, 'Anytime Fitness', '215 S 6th St Ste A', 'Adel, IA	', '(515) 993-3333', 'jane.doe@anytimefitness.com (77.3%)', 31.98),
(29, 'Anytime Fitness', '2127 N Summit St', 'Arkansas City, KS', '(620) 307-6566', 'jane.doe@anytimefitness.com (77.3%)', 21.76),
(30, 'Anytime Fitness', '372 Diederich Blvd', 'Ashland, KY', '(606) 326-0033', 'jane.doe@anytimefitness.com (77.3%)', 20.99),
(31, 'Anytime Fitness', '3015 Veterans Memorial Dr', 'Abbeville, LA', '(337) 385-2812', 'jane.doe@anytimefitness.com (77.3%)', 16.99),
(32, 'Anytime Fitness', '91 Auburn St', 'Portland (Auburn St), ME', '(207) 878-2008', 'jane.doe@anytimefitness.com (77.3%)', 50),
(33, 'Anytime Fitness', '1550 Whitehall Rd.', 'Annapolis, MD', '443.781.4343', 'jane.doe@anytimefitness.com (77.3%)', 46),
(34, 'Anytime Fitness', '100 Powder Mill Rd', 'Acton, MA', '(978) 461-2800', 'jane.doe@anytimefitness.com (77.3%)', 46),
(35, 'Anytime Fitness', '1099 Saint Claire River Dr', 'Algonac, MI', '(810) 512-4224', 'jane.doe@anytimefitness.com (77.3%)', 23.99),
(36, 'Anytime Fitness', '2508 Bridge Ave', 'Albert Lea, MN', '507-377-8451', 'jane.doe@anytimefitness.com (77.3%)', 21.99),
(37, 'Anytime Fitness', '60383 Cotton Gin Port Rd', 'Amory, MS', '(662) 257-6330', 'jane.doe@anytimefitness.com (77.3%)', 52),
(38, 'Anytime Fitness', '772 SW East US Hwy 40', 'Blue Springs, MO', '816-841-8841', 'jane.doe@anytimefitness.com (77.3%)', 16.87),
(39, 'Anytime Fitness', '	2724 Montana Ave', 'Billings (Montana Ave), MT', '(406) 294-0170', 'jane.doe@anytimefitness.com (77.3%)', 20.99),
(40, 'Anytime Fitness', '2317 N 6th St #10', 'Beatrice, NE', '(402) 228-2277', 'jane.doe@anytimefitness.com (77.3%)', 16.97),
(41, 'Anytime Fitness', '4530 S Carson St', 'Carson City, NV', '(775) 885-7771', 'jane.doe@anytimefitness.com (77.3%)', 34),
(42, 'Anytime Fitness', 'Northwood, NH', '262 1st NH Turnpike Ste. 1', '(603) 942-6027', 'jane.doe@anytimefitness.com (77.3%)', 28),
(43, 'Anytime Fitness', '597 Shiloh Pike', 'Bridgeton, NJ', '(856) 391-5900', 'jane.doe@anytimefitness.com (77.3%)', 46),
(44, 'Anytime Fitness', '1300 Hamilton Rd', 'Alamogordo, NM', '	(575) 439-8100', 'jane.doe@anytimefitness.com (77.3%)', 21.99),
(45, 'Anytime Fitness', '720 N Bedford Rd', 'Bedford Hills, NY', '(914) 648-0055', 'jane.doe@anytimefitness.com (77.3%)', 20.99),
(46, 'Anytime Fitness', '805 Patton Ave', 'Asheville, NC', '(828) 505-3715', 'jane.doe@anytimefitness.com (77.3%)', 21.99),
(48, 'Anytime Fitness', '4600 N 19th St Ste 501', 'Bismarck, ND', '(701) 751-0448', 'jane.doe@anytimefitness.com (77.3%)', 16.99),
(49, 'Anytime Fitness', '4600 N 19th St Ste 501', 'Bismarck, ND', '(701) 751-0448', 'jane.doe@anytimefitness.com (77.3%)', 46),
(50, 'Anytime Fitness', '4600 N 19th St Ste 501', 'Bismarck, ND', '(701) 751-0448', 'jane.doe@anytimefitness.com (77.3%)', 19),
(51, 'Anytime Fitness', '212 W Main St', 'Amelia, OH', '(513) 947-2345', 'jane.doe@anytimefitness.com (77.3%)', 12),
(52, 'Anytime Fitness', '228 E Market St', 'Celina, OH', '(567) 876-1399', 'jane.doe@anytimefitness.com (77.3%)', 12),
(53, 'Anytime Fitness', '1624 E Perry St', 'Port Clinton, OH', '(419) 967-2255', 'jane.doe@anytimefitness.com (77.3%)', 12),
(54, 'Anytime Fitness', '265 Benedict Ave Ste 100', 'Norwalk, OH', '(419) 663-8663', 'jane.doe@anytimefitness.com (77.3%)', 14),
(55, 'Anytime Fitness', '2119 Elida Rd', 'Lima, OH', '(419) 221-0030', 'jane.doe@anytimefitness.com (77.3%)', 18),
(56, 'Anytime Fitness', '1624 Norton Rd', 'Hudson, OH', '(330) 655-1331', 'jane.doe@anytimefitness.com (77.3%)', 12),
(57, 'Anytime Fitness', '534 E Main St', 'Jackson, OH', '(740) 971-1128', 'jane.doe@anytimefitness.com (77.3%)', 12),
(58, 'Anytime Fitness', '1412 Scott St', 'Napoleon, OH', '(419) 573-8550', 'jane.doe@anytimefitness.com (77.3%)', 12),
(59, 'Anytime Fitness', '1624 E Perry St', 'Port Clinton, OH', '(419) 967-2255', 'jane.doe@anytimefitness.com (77.3%)', 16.99),
(60, 'Anytime Fitness', '4721 Liberty Ave', 'Vermilion, OH', '(440) 963-7170', 'jane.doe@anytimefitness.com (77.3%)', 16.99),
(61, 'Anytime Fitness', '940 N High St', 'Worthington, OH', '614-597-1244', 'jane.doe@anytimefitness.com (77.3%)', 12),
(62, 'Anytime Fitness', '1513 N Rockford Rd', 'Ardmore, OK', '(580) 223-5252', 'jane.doe@anytimefitness.com (77.3%)', 12),
(63, 'Anytime Fitness', '7140 NW 23rd St', 'Bethany (23rd St), OK', '(405) 470-4440', 'jane.doe@anytimefitness.com (77.3%)', 12),
(64, 'Anytime Fitness', '2760 Pacific Blvd SE', 'Albany, OR', '(541) 981-8552', 'jane.doe@anytimefitness.com (77.3%)', 23.69),
(65, 'Anytime Fitness', '955 NW Kings Blvd', 'Corvallis, OR', '(541) 758-9100', 'jane.doe@anytimefitness.com (77.3%)', 24),
(66, 'Anytime Fitness', '1399 Monmouth St', 'Independence, OR', '(503) 837-0949', 'jane.doe@anytimefitness.com (77.3%)', 12),
(67, 'Anytime Fitness', '1831 Avalon St.', 'Klamath Falls, OR', '(541) 891-4084', 'jane.doe@anytimefitness.com (77.3%)', 41.99),
(68, 'Anytime Fitness', '2288 Brodhead Rd', 'Aliquippa (Hopewell Township), PA', '724.302.3001', 'jane.doe@anytimefitness.com (77.3%)', 12),
(69, 'Anytime Fitness', '135 Towne Square Way', 'Brentwood, PA', '412.892.9064', 'jane.doe@anytimefitness.com (77.3%)', 12),
(70, 'Anytime Fitness', '623 Conchester Highway', 'Boothwyn, PA', '(610) 243-1777', 'jane.doe@anytimefitness.com (77.3%)', 12),
(71, 'Anytime Fitness', '204 Newberry Pkwy', 'Etters, PA', '(717) 610-3166', 'jane.doe@anytimefitness.com (77.3%)', 12),
(72, 'Anytime Fitness', '603 E Market St', 'Danville, PA', '	(570) 271-0100', 'jane.doe@anytimefitness.com (77.3%)', 12),
(73, 'Anytime Fitness', '5055 William Flynn Hwy', 'Gibsonia, PA', '(724) 443-3020', 'jane.doe@anytimefitness.com (77.3%)', 12),
(74, 'Anytime Fitness', '3443 Wilmington Rd', 'New Castle, PA', '(724) 654-2470', 'jane.doe@anytimefitness.com (77.3%)', 23),
(75, 'Anytime Fitness', '3117 Cape Horn Rd', 'Red Lion, PA', '(717) 246-2420	', 'jane.doe@anytimefitness.com (77.3%)', 12),
(76, 'Anytime Fitness', '1100 W Wyomissing Blvd', 'West Lawn, PA', '(484) 987-2624', 'jane.doe@anytimefitness.com (77.3%)', 12),
(77, 'Anytime Fitness', '930 S Richland Ave', 'York, PA', '(717) 850-9889', 'jane.doe@anytimefitness.com (77.3%)', 12),
(78, 'Anytime Fitness', '1018 Wyoming Ave', 'Wyoming, PA', '570.338.2839', 'jane.doe@anytimefitness.com (77.3%)', 12),
(79, 'Anytime Fitness', '180-188 County Rd Ste B', 'Barrington, RI', '401-477-9331', 'jane.doe@anytimefitness.com (77.3%)', 12),
(80, 'Anytime Fitness', '1051 Ten Rod Rd', 'North Kingstown, RI', '(401) 386-9001', 'jane.doe@anytimefitness.com (77.3%)', 12),
(81, 'Anytime Fitness', '288 E Main Rd', 'Middletown, RI', '401-619-4250', 'jane.doe@anytimefitness.com (77.3%)', 12),
(82, 'Anytime Fitness', '415 Brooks Rd.', 'Andrews, SC', '(843) 630-6061', 'jane.doe@anytimefitness.com (77.3%)', 21.99),
(83, 'Anytime Fitness', '1237 Chapin Rd Suite C', 'Chapin, SC', '(803) 941-7397', 'jane.doe@anytimefitness.com (77.3%)', 12),
(84, 'Anytime Fitness', '715 University Vlg Dr', 'Blythewood, SC', '(803) 786-2988', 'jane.doe@anytimefitness.com (77.3%)', 19.99),
(85, 'Anytime Fitness', '2153 E Main St\r\nSte. A-1', 'Duncan, SC', '(864) 336-2565', 'jane.doe@anytimefitness.com (77.3%)', 12),
(86, 'Anytime Fitness', '321 S Main Street', 'Aberdeen, SD', '(605) 262-5010', 'jane.doe@anytimefitness.com (77.3%)', 12),
(87, 'Anytime Fitness', '908 E Redwood Blvd', 'Brandon, SD', '(605) 582-4104', 'jane.doe@anytimefitness.com (77.3%)', 12),
(88, 'Anytime Fitness', '111 N Main St', 'Canton, SD', '(605) 836-9530', 'jane.doe@anytimefitness.com (77.3%)', 12),
(89, 'Anytime Fitness', '116 E Jackson St', 'Bolivar, TN', '(731) 518-9110', 'jane.doe@anytimefitness.com (77.3%)', 12),
(90, 'Anytime Fitness', '2690 Madison St Ste 160', 'Clarksville, TN', '(931) 820-1051', 'jane.doe@anytimefitness.com (77.3%)', 12),
(91, 'Anytime Fitness', '1117 E N 10th St', 'Abilene (E N 10th St), TX', '(325) 437-2299', 'jane.doe@anytimefitness.com (77.3%)', 12),
(92, 'Anytime Fitness', '4102 Buffalo Gap Rd B', 'Abilene (Buffalo Gap Rd), TX', '(325) 232-8694', 'jane.doe@anytimefitness.com (77.3%)', 12),
(93, 'Anytime Fitness', '533 W 750 S', 'Bountiful, UT, UT', '385-414-2768', 'jane.doe@anytimefitness.com (77.3%)', 12),
(94, 'Anytime Fitness', '120 Depot St', 'Bennington, VT', '(802) 681-0161', 'jane.doe@anytimefitness.com (77.3%)', 43.99),
(95, 'Anytime Fitness', '220 Cook St', 'Abingdon, VA', '(276) 525-1278', 'jane.doe@anytimefitness.com (77.3%)', 12),
(96, 'Anytime Fitness', '2616 Simpson Ave', 'Aberdeen, WA', '(360) 637-9111', 'jane.doe@anytimefitness.com (77.3%)', 12),
(97, 'Anytime Fitness', '	1198 W Main St', 'Bridgeport, WV', '	(304) 933-3192', 'jane.doe@anytimefitness.com (77.3%)', 12),
(98, 'Anytime Fitness', '501 Superior St', 'Antigo, WI', '(715) 350-4444	', 'jane.doe@anytimefitness.com (77.3%)', 12),
(99, 'Anytime Fitness', '	534 Yellowstone Ave', 'Cody, WY', '	(307) 578-8550', 'jane.doe@anytimefitness.com (77.3%)', 12),
(100, 'Anytime Fitness', '943 Amoretti St', 'Lander, WY', '(307) 332-2811', 'jane.doe@anytimefitness.com (77.3%)', 29.89),
(101, 'Anytime Fitness', '3125 Old Fairhaven Pkwy Ste 101', 'Bellingham (Fairhaven), WA', '(360) 788-5900', 'jane.doe@anytimefitness.com (77.3%)', 31),
(102, 'Anytime Fitness', '8115 Birch Bay Sq St', 'Blaine, WA', '(360) 393-3330', 'jane.doe@anytimefitness.com (77.3%)', 25.99),
(103, 'Anytime Fitness', '135 Jefferson Ave', 'Buckley, WA', '(360) 829-5156', 'jane.doe@anytimefitness.com (77.3%)', 29.99),
(104, 'Anytime Fitness', '515 Harrison Ave. Ste. B', 'Centralia, WA', '(360) 736-1900', 'jane.doe@anytimefitness.com (77.3%)', 39.99),
(105, 'Anytime Fitness', '3 W Crawford St', 'Deer Park, WA', '(509) 276-5880', 'jane.doe@anytimefitness.com (77.3%)', 39),
(106, 'Anytime Fitness', '21819 Marine View Dr S', 'Des Moines, WA', '206-460-1212', 'jane.doe@anytimefitness.com (77.3%)', 29.99),
(107, 'Anytime Fitness', '2620 Williamson Pl NW', 'Dupont, WA', '(253) 267-5425', 'jane.doe@anytimefitness.com (77.3%)', 29.99),
(108, 'Anytime Fitness', '515 Grant Rd', 'East Wenatchee, WA', '509-888-1559', 'jane.doe@anytimefitness.com (77.3%)', 32.95),
(109, 'Anytime Fitness', '22824 100th Ave West', 'Edmonds, WA', '(425) 670-2373', 'jane.doe@anytimefitness.com (77.3%)', 29.99),
(110, 'Anytime Fitness', '2305 W Dolarway Rdt', 'Ellensburg, WA', '(509) 925-5445', 'jane.doe@anytimefitness.com (77.3%)', 48),
(111, 'Anytime Fitness', '3 Shouweiler Rd', 'Elma, WA', '(360) 861-8340', 'jane.doe@anytimefitness.com (77.3%)', 21.5),
(112, 'Anytime Fitness', '514 Basin St NW', 'Ephrata, WA', '(509) 754-1066', 'jane.doe@anytimefitness.com (77.3%)', 39),
(113, 'Anytime Fitness', '1614 SW Dash Point Rd', 'Federal Way, WA', '(206) 212-6176', 'jane.doe@anytimefitness.com (77.3%)', 39.95),
(114, 'Anytime Fitness', '	5905 Portal Way', 'Ferndale, WA', '(360) 393-3779', 'jane.doe@anytimefitness.com (77.3%)', 29.99),
(115, 'Anytime Fitness', '5275 Olympic Dr NW', 'Gig Harbor, WA', '(253) 509-2747', 'jane.doe@anytimefitness.com (77.3%)', 40),
(116, 'Anytime Fitness', '121 Sunnyside Ave', 'Granger, WA', '(509) 383-6111', 'jane.doe@anytimefitness.com (77.3%)', 35.99),
(117, 'Anytime Fitness', '2909 S Quillan St Ste 164', 'Kennewick, WA', '509-870-3730', 'jane.doe@anytimefitness.com (77.3%)', 30),
(118, 'Anytime Fitness', '13210 SE 240th St Ste A-1', 'Kent, WA', '(253) 487-1604', 'jane.doe@anytimefitness.com (77.3%)', 29.99),
(119, 'Anytime Fitness', '6533 132nd Ave NE', 'Kirkland, WA', '(425) 968-2341', 'jane.doe@anytimefitness.com (77.3%)', 26),
(120, 'Anytime Fitness', '4200 6th Ave SE Suite 101', 'Lacey, WA', '(360) 456-5100', 'jane.doe@anytimefitness.com (77.3%)', 42.99),
(121, 'Anytime Fitness', '25 95th Dr NE Ste 107', 'Lake Stevens, WA', '(425) 334-1200', 'jane.doe@anytimefitness.com (77.3%)', 27),
(122, 'Anytime Fitness', '8520 Steilacoom Blvd SW', 'Lakewood, WA', '(253) 589-5277', 'jane.doe@anytimefitness.com (77.3%)', 33.95),
(123, 'Anytime Fitness', '23505 E Appleway', 'Liberty Lake, WA', '(509) 891-6800	', 'jane.doe@anytimefitness.com (77.3%)', 21.99),
(124, 'Anytime Fitness', '6918 Hannegan Rd', 'Lynden, WA', '(360) 306-8668', 'jane.doe@anytimefitness.com (77.3%)', 29.99),
(125, 'Anytime Fitness', '111 North 17th St', 'Lynden, WA', '(360) 543-8200', 'jane.doe@anytimefitness.com (77.3%)', 29.99),
(126, 'Anytime Fitness', '4114 198th St SW', 'Lynnwood, WA', '(425) 409-9067', 'jane.doe@anytimefitness.com (77.3%)', 27.5),
(127, 'Anytime Fitness', '1523 132nd St SE', 'Mill Creek, WA', '(425) 225-6116', 'jane.doe@anytimefitness.com (77.3%)', 24),
(128, 'Anytime Fitness', '900 Meridian Ave E Ste 30', 'Milton, WA', '(253) 517-8431', 'jane.doe@anytimefitness.com (77.3%)', 29.99),
(129, 'Anytime Fitness', '619 N Stratford Rd', 'Moses Lake, WA', '(509) 764-0933', 'jane.doe@anytimefitness.com (77.3%)', 23.99),
(130, 'Anytime Fitness', '304 West Seattle Ave', 'Moxee, WA', '(509) 902-8212', 'jane.doe@anytimefitness.com (77.3%)', 34.99),
(131, 'Anytime Fitness', '205 W Stewart Rd', 'Mt Vernon, WA', '(360) 873-8377', 'jane.doe@anytimefitness.com (77.3%)', 28.99),
(132, 'Anytime Fitness', '205 W Stewart Rd', 'Mt Vernon, WA', '(360) 873-8377', 'jane.doe@anytimefitness.com (77.3%)', 28.99),
(133, 'Anytime Fitness', '401 Washington Ave. N.', 'Orting, WA', '(360) 893-2443', 'jane.doe@anytimefitness.com (77.3%)', 46),
(134, 'Anytime Fitness', '740 E Main St PO Box 506', 'Othello, WA', '(509) 488-3484', 'jane.doe@anytimefitness.com (77.3%)', 24.99),
(135, 'Anytime Fitness', '112 Del Guzzi Dr Ste. 5', 'Port Angeles, WA', '(360) 457-3200', 'jane.doe@anytimefitness.com (77.3%)', 57.95),
(136, 'Anytime Fitness', '690 SE Bishop Blvd Ste A', 'Pullman, WA', '(509) 332-3100', 'jane.doe@anytimefitness.com (77.3%)', 19.5),
(137, 'Anytime Fitness', '14312 Meridian Ave E', 'Puyallup, WA', '(253) 268-3352', 'jane.doe@anytimefitness.com (77.3%)', 28.99),
(138, 'Anytime Fitness', '228 E Market St', 'Celina, OH', '(567) 876-1399', 'jane.doe@anytimefitness.com', 27);

-- --------------------------------------------------------

--
-- Table structure for table `userinformation`
--

CREATE TABLE `userinformation` (
  `UserID` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Age` int(11) DEFAULT NULL,
  `Weight` decimal(5,2) DEFAULT NULL,
  `Height` decimal(5,2) DEFAULT NULL,
  `Gender` varchar(10) NOT NULL,
  `ActivityLevel` varchar(20) DEFAULT NULL,
  `TargetWeight` decimal(5,2) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `userinformation`
--

INSERT INTO `userinformation` (`UserID`, `Name`, `Age`, `Weight`, `Height`, `Gender`, `ActivityLevel`, `TargetWeight`, `email`, `Password`) VALUES
(1, '', NULL, NULL, NULL, '', NULL, NULL, NULL, '$2y$10$55cowLoVtbxOFxtUfKn/6.B.fNO1LXoUWfiflF46YfQmb1f9zUiqe'),
(2, '', 45, 999.99, 0.00, '0', 'Moderate', 999.99, 'sdsd@gmail.com', '$2y$10$78SaTme2O43qcNO/VucKJeWGFQ6xMW7fGqqbFbInXFBMMnpncXdxO'),
(3, '', NULL, NULL, NULL, '', NULL, NULL, NULL, '$2y$10$tu1Ckxne4PiqhQ2vtIXtx.33AdQTIGBFGlebs0lQqmGN4wO3WVbre'),
(4, '', 45, 999.99, 0.00, '0', 'Moderate', 999.99, 'sdsd@gmail.com', '$2y$10$4F6zUrMcjPv34THwtIxrXOgnxwi9cwFH3czET7Qt5YzkCIAZgrz8.'),
(5, '', 45, 999.99, 0.00, '0', 'Moderate', 999.99, 'sdsd@gmail.com', '$2y$10$VD6ZIcBxekfPXpzxpe611OLIEjOzQP5Ex2GywQ/2Xxtakbftn7l76'),
(6, '', NULL, NULL, NULL, '', NULL, NULL, NULL, '$2y$10$i2ZohdX5up88JB7NOqjT1e9mSBjquoInrPKIy3v79Ia6qj7udVIi2'),
(7, '', NULL, NULL, NULL, '', NULL, NULL, NULL, '$2y$10$oT2EBCz3fqkH2oC4sMye8usdtjdovoLV5EBTzKcFBOb4k9v5.WecW'),
(8, '', NULL, NULL, NULL, '', NULL, NULL, NULL, '$2y$10$g2lIeLSDvj7OjI.vLAOZGuxWMwdyywO3kdJFUyPG2TXrZNvG3VQke'),
(9, '', 2, 2.00, 1.00, '0', 'Moderate', 3.00, 'sdsd@gmail.com', '$2y$10$ZgEvOPH62hiFBzATAboSNO608SBX0bKN3IX0/IjvIASkqrkmv7mI6'),
(10, '', 2, 2.00, 1.00, '0', 'Moderate', 3.00, 'sdsd@gmail.com', '$2y$10$IjjG0MbXkuaOrFyhsvlKqelYdZBPQHqwdVDQvWLo/0fWA1q1mRTOW'),
(11, '', 2, 2.00, 1.00, '0', 'Active', 3.00, 'sdsd@gmail.com', '$2y$10$952hrPDVlA0huM0rubhCIefHS0wvFmvcG56xlUPOpWYsTaQPCfCUS'),
(12, '', 2, 2.00, 1.00, 'Male', 'Active', 3.00, 'sdsd@gmail.com', '$2y$10$7rsVOFfUGqSXwOhrFCjrzeMbrlGrYNs5tF6BGHj080u5rZ3wSnCYC'),
(13, '', 2, 2.00, 1.00, 'Female', 'Active', 3.00, 'sdsd@gmail.com', '$2y$10$J5DKgjftp58ayI.ADOSVEeUlXI4vLbuTCqPxt1PhFAUwboSeR6jTq'),
(14, '', 12, 12.00, 12.00, 'Female', 'Moderate', 12.00, 'go@gmail.com', '$2y$10$rxmiqScpfJptgiMDzMnSyen/4uR5S3UpZCgWWnTzVeXqpjzmMaiAy'),
(15, '', 1, 1.00, 1.00, 'Female', 'Moderate', 1.00, 'af@gmail.com', '$2y$10$e7bdGWf/vT04ltnRBIXNl.M17EpLAMTujPhSmHaWsvXvfAs48PLtC');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dietplans`
--
ALTER TABLE `dietplans`
  ADD PRIMARY KEY (`PlanID`);

--
-- Indexes for table `exerciseroutines`
--
ALTER TABLE `exerciseroutines`
  ADD PRIMARY KEY (`RoutineID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `gym`
--
ALTER TABLE `gym`
  ADD PRIMARY KEY (`GymID`);

--
-- Indexes for table `userinformation`
--
ALTER TABLE `userinformation`
  ADD PRIMARY KEY (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dietplans`
--
ALTER TABLE `dietplans`
  MODIFY `PlanID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `userinformation`
--
ALTER TABLE `userinformation`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `exerciseroutines`
--
ALTER TABLE `exerciseroutines`
  ADD CONSTRAINT `exerciseroutines_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `userinformation` (`UserID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
