<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "database_task";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT
ExerciseType,
Duration,
IntensityLevel,
CaloriesBurned
FROM exerciseroutines
WHERE ExerciseType = 'Running'";

$result = $conn->query($sql);

if ($result === false) {
    die("Error: " . $conn->error);
}

echo "<link rel='stylesheet' type='text/css' href='style.css'>";

if ($result->num_rows > 0) {
    echo "<table class='styled-table'><thead><tr><th>ExerciseType</th><th>Duration</th><th>IntensityLevel</th><th>CaloriesBurned</th></tr></thead><tbody>";
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["ExerciseType"]."</td><td>".$row["Duration"]."</td><td>".$row["IntensityLevel"]."</td><td>".$row["CaloriesBurned"]."</td></tr>";
    }
    echo "</tbody></table>";
} else {
    echo "0 results";
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="yoga.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300&family=Kodchasan:wght@300;500&display=swap" rel="stylesheet">
    <title>Diet Plan</title>
</head>
<body>

</body>
</html>
