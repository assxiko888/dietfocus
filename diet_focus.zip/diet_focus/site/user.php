<?php
$servername = "localhost";
$username = "root";
$password = "";

$conn = new mysqli($servername, $username, $password);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="user.css">
  <title>Diet_Focus</title>
</head>
<body>
  <!----------------------------------HEADER BEGINING------------------------------------->
  <header>
        <div class="logo"><img src="images/header/acetone-2024521-111521-736 1 (1).png"></div>
        <div class="hamburger">
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
        </div>
        <nav class="nav-bar">
            <ul>
                <li class="button-1">
                    <a href="dietplan.php">Diet</a>
                </li>
                <li class="button-2">
                    <a href="home.php" >Exersice</a>
                </li>
                <li class="button-3">
                    <a href="home.php">Gym</a>
                </li>
                <li class="button-4">
                    <a href="user.php">Profile</a>
                </li>
            </ul>
        </nav>
    </header>
    <script>
        hamburger = document.querySelector(".hamburger");
        hamburger.onclick = function() {
            navBar = document.querySelector(".nav-bar");
            navBar.classList.toggle("active");
        }
    </script>
<!----------------------------------HEADER END------------------------------------->


<!------------------------USER SECTION------------------------>
<section>
    <div class="profile-container">
        <div class="header">
            <img src="images/user/adbcb33821cf2749b15758c259f35bae 1 (1).jpg" alt="Forest background" class="background-img">
            <div class="profile-pic-container">
                <img src="images/user/images.png" alt="Profile Picture" class="profile-pic" id="profilePic">
            </div>
        </div>
        <div class="profile-info">
            <?php
            include('db.php');

            $sql = "SELECT Name, Age FROM userinformation ORDER BY UserID Desc LIMIT 1"; 
            $res = mysqli_query($con, $sql);

            if(mysqli_num_rows($res) > 0) {
                $row = mysqli_fetch_assoc($res);
                echo "<td>".$row['Name']." "."</td>";
                echo "<td>".$row[ 'Age']." years old</td>";
                echo "</table>";
            } else {
                echo "No data found :(";
            }
            ?>
            <style>

            </style>
        </div>
        <div class="profile-details">
            <div class="detail-item gender">weight</div>
            <div class="detail-item gender">height</div>
            <div class="detail-item gender">activity level</div>
            <div class="detail-item gender">target weight</div>
            <div class="detail-item gender">gender</div>
        </div>
        <?php
        include('db.php');

        $sql = "SELECT * FROM userinformation ORDER BY UserID Desc LIMIT 1"; 
        $res = mysqli_query($con, $sql);

        if(mysqli_num_rows($res) > 0) {
            echo "<table border='1'>";
            $row = mysqli_fetch_assoc($res);
            echo "<tr>";
            echo "<td>".$row['Weight']."</td>";
            echo "<td>".$row['Height']."</td>";
            echo "<td>".$row['ActivityLevel']."</td>";
            echo "<td>".$row['TargetWeight']."</td>";
            echo "<td>".$row['Gender']."</td>";
            echo "</tr>";
            echo "</table>";
        } else {
            echo "No data found :(";
        }
        ?>
        <style>
            table {
                margin-bottom: 100px;
                width: 100%;
                margin: 0 0 ; 
                border-collapse: collapse;
                border-spacing: 0;
                table-layout: fixed; 
            }
            th, td {
                padding: 10px;
                text-align: center;
                border: 1px solid #ddd;
                white-space: nowrap;
            }
            th {
                background-color: #f2f2f2;
            }
            tr:nth-child(even) {
                background-color: #f9f9f9;
            }
            tr:hover {
                background-color: #ccc; 
            }
        </style>
        <label for="upload" class="upload-btn">upload</label>
        <input type="file" id="upload" accept="image/*" style="display: none;" onchange="loadFile(event)">
        <div id="image-preview"></div>
        <script>
            function loadFile(event) {
                var image = document.getElementById('profilePic');
                image.src = URL.createObjectURL(event.target.files[0]);
                image.onload = function() {
                    URL.revokeObjectURL(image.src); 
                }
            }
        </script>
    </div>
    <script src="scripts.js"></script>
</section>


<?php
include('db.php');
if(isset(($_GET["UserID"]))) {
    $mm = $_GET['UderID'];

    $dbinfo = "Select Name, Age, Weight, Height, Gender, ActivityLevel, TargetWeight FROM userinformation where UserID='$mm'";
    $dbresult = mysqli_query($conn, $dbinfo, );
    $rt = mysqli_fetch_array($dbresult);


    $f = $rt['Name'];
    $age = $rt['age'];
    $weight = $rt['weight'];
    $height = $rt['height'];
    $gender = $rt['gender'];
    $level = $rt['activity level'];
    $target = $rt['target weight'];

}
?>
<!------------------------USER SECTION------------------------>


<!--------------------FOOOTER--------------------------------->
<footer>
        <div class="dividerline">
        </div>
        <div class="footer-section">
            <img src="images/footer/logo.png" alt="Logo" class="footer-logo">
            <p>Your Ultimate Diet Companion is dedicated to helping you achieve your health and wellness goals through personalized meal plans and expert advice.</p>
            <div class="social-media">
                <a href="https://www.facebook.com" target="_blank"><img src="images/footer/Icon.png" alt="Facebook"></a>
                <a href="https://www.twitter.com" target="_blank"><img src="images/footer/Icon-1.png" alt="Twitter"></a>
                <a href="https://www.instagram.com" target="_blank"><img src="images/footer/Icon-2.png" alt="Instagram"></a>
                <a href="https://www.pinterest.com" target="_blank"><img src="images/footer/Icon-3.png" alt="Pinterest"></a>
            </div>
        </div>
        <div class="footer-section">
            <h3>Quick Links</h3>
            <ul>
                <li><a href="http://localhost/site/home.php">Home</a></li>
                <li><a href="http://localhost/site/dietplan.php">Dietplan</a></li>
                <li><a href="http://localhost/site/user.php">Account</a></li>
            </ul>
        </div>
        <div class="footer-section">
            <h3>Contact Us</h3>
            <p>Email: support@dietcompanion.com</p>
            <p>Address: 123 Healthy Way, Wellness City, Fitland</p>
            <p>Phone: (123) 456-7890</p>
        </div>
    </footer>
<!--------------------FOOOTER--------------------------------->

</body>
</html>