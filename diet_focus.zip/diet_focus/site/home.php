<?php
$servername = "localhost";
$username = "root";
$password = "";

$conn = new mysqli($servername, $username, $password);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="home.css">
  <title>Diet_Focus</title>
</head>
<body>
  <!----------------------------------HEADER BEGINING------------------------------------->
  <header>
        <div class="logo"><img src="images/header/acetone-2024521-111521-736 1 (1).png"></div>
        <div class="hamburger">
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
        </div>
        <nav class="nav-bar">
            <ul>
                <li class="button-1">
                    <a href="dietplan.php">Diet</a>
                </li>
                <li class="button-2">
                    <a href="" >Exersice</a>
                </li>
                <li class="button-3">
                    <a href="">Gym</a>
                </li>
                <li class="button-4">
                    <a href="user.php">Profile</a>
                </li>
            </ul>
        </nav>
    </header>
 
<!----------------------------------HEADER END------------------------------------->


   <!------------------WELLCOME PART------------------------>
<section>
        <div class="img">
            <img src="images/body/wellcome/220353.jpg">
            <div class="overlay">
                <h1>Wellcome to Your Diet Companion</h1>
                <h3>Find personalized meal plans, healthy recipes, and expert advice to achieve your dietary goals. start your journey to a healthier, happier you today!</h3>
                <button onclick="window.location.href='register.php'">Login</button>
            </div>
        </div>
    </section>
   <!------------------WELLCOME PART------------------------>
    


<!--------------------------------EXERSICEEES BIGING----------------------------------------------->
    <section class="container">
        <h1 class="exersices-text">Exercises</h1>
        <div class="boxes">
            <div class="box" data-content="content1">
                <img src="images/body/exersices/Yoga.jpg" onclick="window.location.href='e/yoga.php'" alt="Image 1">
                <h3>Yoga</h3>
                <p>Intensity Level</p>
                <h2>Low</h4>
            </div>
            <div class="box" data-content="content2">
                <img src="images/body/exersices/running.jpg" onclick="window.location.href='e/run.php'" alt="Image 2">
                <h3>Running</h3>
                <p>Intensity Level</p>
                <h2>High</h4>
            </div>
            <div class="box" data-content="content3">
                <img src="images/body/exersices/walking.jpg" onclick="window.location.href='e/walking.php'" alt="Image 3">
                <h3>Walking</h3>
                <p>Intensity Level </p>
                <h2>Low</h4>
            </div>
            <div class="box" data-content="content4">
                <img src="images/body/exersices/cycling.jpg" onclick="window.location.href='e/cycling.php'" alt="Image 1">
                <h3>Cycling</h3>
                <p>Intensity Level</p>
                <h2>Medium</h4>
            </div>
            <div class="box" data-content="content5">
                <img src="images/body/exersices/weightlifting.jpg" onclick="window.location.href='e/weight.php'" alt="Image 2">
                <h3>Weightlifting</h3>
                <p>Intensity Level</p>
                <h2>High</h4>
            </div>
            <div class="box" data-content="content6">
                <img src="images/body/exersices/Swimming.jpg" onclick="window.location.href='e/swim.php'" alt="Image 3">
                <h3>Swimming</h3>
                <p>Intensity Level</p>
                <h2>High</h4>
            </div>
        </div>
<!--------------------------------EXERSICEEES ENDS----------------------------------------------->

<!--------------------GYM FIND----------------->
    </section>
    <section>
        <div class="image_gym">
            <img src="images/body/wellcome/1345029.png" alt="Gym Image" class="image_gym_gym_image">
            <h2 class="h2gym">Looking for ideal GYM?</h2> 
            <h3 class="h3gym">Search your city and find the perfect match for your fitness needs here down bellow</h3>
            <div class="searchbar_gym">
    <form method="post">
        <input type="text" name="str" required/>
        <input type="submit" name="submit" value="Search"/>
    </form>
</div>

<?php
include('db.php');
if(isset($_POST['submit'])){
    $str=mysqli_real_escape_string($con,$_POST['str']);
    $sql="SELECT * FROM gym WHERE city LIKE '%$str%'";
    $res=mysqli_query($con,$sql);
    if(mysqli_num_rows($res)>0){
        echo "<table border='1'>";
        echo "<tr>";
        echo "<th>GymID</th>";
        echo "<th>Name</th>";
        echo "<th>Address</th>";
        echo "<th>City</th>";
        echo "<th>Phone</th>";
        echo "<th>Email</th>";
        echo "<th>Membership Price</th>";
        echo "</tr>";
        while($row=mysqli_fetch_assoc($res)){
            echo "<tr>";
            echo "<td>".$row['GymID']."</td>";
            echo "<td>".$row['Name']."</td>";
            echo "<td>".$row['Address']."</td>";
            echo "<td>".$row['City']."</td>";
            echo "<td>".$row['Phone']."</td>";
            echo "<td>".$row['Email']."</td>";
            echo "<td>".$row['MembershipPrice']."</td>";
            echo "</tr>";
        }
        echo "</table>";
    }else{
        echo "no data found:(";
    }
}
?>
        </div>
        </section>
        
<!--------------------GYM FIND--------------------------------->



<!--------------------FOOOTER--------------------------------->
  <footer>
        <div class="dividerline">
        </div>
        <div class="footer-section">
            <img src="images/footer/logo.png" alt="Logo" class="footer-logo">
            <p>Your Ultimate Diet Companion is dedicated to helping you achieve your health and wellness goals through personalized meal plans and expert advice.</p>
            <div class="social-media">
                <a href="https://www.facebook.com" target="_blank"><img src="images/footer/Icon.png" alt="Facebook"></a>
                <a href="https://www.twitter.com" target="_blank"><img src="images/footer/Icon-1.png" alt="Twitter"></a>
                <a href="https://www.instagram.com" target="_blank"><img src="images/footer/Icon-2.png" alt="Instagram"></a>
                <a href="https://www.pinterest.com" target="_blank"><img src="images/footer/Icon-3.png" alt="Pinterest"></a>
            </div>
        </div>
        <div class="footer-section">
            <h3>Quick Links</h3>
            <ul>
                <li><a href="http://localhost/site/home.php">Home</a></li>
                <li><a href="http://localhost/site/dietplan.php">Dietplan</a></li>
                <li><a href="http://localhost/site/user.php">Account</a></li>
            </ul>
        </div>
        <div class="footer-section">
            <h3>Contact Us</h3>
            <p>Email: support@dietcompanion.com</p>
            <p>Address: 123 Healthy Way, Wellness City, Fitland</p>
            <p>Phone: (123) 456-7890</p>
        </div>
    </footer>
<!--------------------FOOOTER--------------------------------->

</body>
</html>