<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "database_task";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT PlanID, UserID, DayOfWeek, MealType, FoodItems, Calories, Nutrients, Duration
        FROM dietplans
        WHERE Duration = '2 weeks'";

$result = $conn->query($sql);

echo "<link rel='stylesheet' type='text/css' href='style.css'>";

if ($result->num_rows > 0) {
    echo "<table class='styled-table'><thead><tr><th>PlanID</th><th>UserID</th><th>DayOfWeek</th><th>MealType</th><th>FoodItems</th><th>Calories</th><th>Nutrients</th></tr></thead><tbody>";
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["PlanID"]."</td><td>".$row["UserID"]."</td><td>".$row["DayOfWeek"]."</td><td>".$row["MealType"]."</td><td>".$row["FoodItems"]."</td><td>".$row["Calories"]."</td><td>".$row["Nutrients"]."</td></tr>";
    }
    echo "</tbody></table>";
} else {
    echo "0 results";
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="2w.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300&family=Kodchasan:wght@300;500&display=swap" rel="stylesheet">
    <title>Diet Plan</title>
</head>
<body>
    <button id="showTableButton">Start</button>
    <div id="tableContainer"></div>

    <script>
        document.getElementById("showTableButton").addEventListener("click", function() {
            fetch('data.php')
                .then(response => response.text())
                .then(data => {
                    document.getElementById("tableContainer").innerHTML = data;
                })
                .catch(error => console.error('Error:', error));
        });
    </script>
</body>
</html>

