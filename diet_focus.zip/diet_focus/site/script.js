function loadFile(event) {
    var image = document.getElementById('profilePic');
    image.src = URL.createObjectURL(event.target.files[0]);
}
