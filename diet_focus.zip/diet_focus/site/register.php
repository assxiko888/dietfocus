<?php
session_start();

$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "database_task";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$email = $_POST['email'] ?? null;
$age = $_POST['age'] ?? null;
$gender = $_POST['gender'] ?? null; 
$height = $_POST['height'] ?? null;
$weight = $_POST['weight'] ?? null;
$target_weight = $_POST['target_weight'] ?? null;
$activity_level = $_POST['activity_level'] ?? null;
$password = $_POST['password'] ?? null;
$confirm_password = $_POST['confirm_password'] ?? null;

if ($password !== $confirm_password) {
    die("Passwords do not match!");
}

$hashed_password = password_hash($password, PASSWORD_DEFAULT);

$stmt = $conn->prepare("INSERT INTO userinformation (Email, Age, Weight, Height, Gender, ActivityLevel, TargetWeight, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sisdssss", $email, $age, $weight, $height, $gender, $activity_level, $target_weight, $hashed_password); 

if ($stmt->execute()) {
    echo "New record created successfully";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="register.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300&family=Kodchasan:wght@300;500&display=swap" rel="stylesheet">
    <title>Registration form</title>
</head>
<body>
<!----------------------------------HEADER BEGINING------------------------------------->
<header>
        <div class="logo"><img src="images/header/acetone-2024521-111521-736 1 (1).png"></div>
        <div class="hamburger">
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
        </div>
        <nav class="nav-bar">
            <ul>
                <li class="button-1">
                    <a href="dietplan.php">Diet</a>
                </li>
                <li class="button-2">
                    <a href="home.php" >Exersice</a>
                </li>
                <li class="button-3">
                    <a href="home.php">Gym</a>
                </li>
                <li class="button-4">
                    <a href="user.php">Profile</a>
                </li>
            </ul>
        </nav>
    </header>
    <script>
        hamburger = document.querySelector(".hamburger");
        hamburger.onclick = function() {
            navBar = document.querySelector(".nav-bar");
            navBar.classList.toggle("active");
        }
    </script>
<!----------------------------------HEADER END------------------------------------->
<div class="button-container">
    <a href="login.php" class="login-button">Login</a>
</div>
<div class="additional-text">
    <h4>If you already have an account</h4>
</div>

    <div class="container">
    <div class="login-form">
        <h1>Sign Up</h1>
        <form action="register.php" method="POST">
            <input type="text" name="email" placeholder="Email" required>
            <input type="number" name="age" placeholder="Age" required>

            <h4>Gender</h4>
            <input type="radio" id="female" name="gender" value="Female" required>
            <label for="female">Female</label><br>
            <input type="radio" id="male" name="gender" value="Male" required>
            <label for="male">Male</label><br>


            <input type="number" name="height" placeholder="Height" required>
            <input type="number" name="weight" placeholder="Weight" required>
            <input type="number" name="target_weight" placeholder="Target Weight" required>

            <h4>Activity Level</h4>
            <input type="radio" id="Moderate" name="activity_level" value="Moderate" required>
            <label for="Moderate">Moderate</label><br>
            <input type="radio" id="Active" name="activity_level" value="Active" required>
            <label for="Active">Active</label><br>
            <input type="radio" id="Sedentary" name="activity_level" value="Sedentary" required>
            <label for="Sedentary">Sedentary</label><br>

            <input type="password" name="password" placeholder="Create password" required>
            <input type="password" name="confirm_password" placeholder="Repeat password" required>

            <input type="submit" value="Sign Up">
        </form>
    </div>
</div>

</body>
<!--------------------FOOOTER--------------------------------->
<footer>
        <div class="dividerline">
        </div>
        <div class="footer-section">
            <img src="images/footer/logo.png" alt="Logo" class="footer-logo">
            <p>Your Ultimate Diet Companion is dedicated to helping you achieve your health and wellness goals through personalized meal plans and expert advice.</p>
            <div class="social-media">
                <a href="https://www.facebook.com" target="_blank"><img src="images/footer/Icon.png" alt="Facebook"></a>
                <a href="https://www.twitter.com" target="_blank"><img src="images/footer/Icon-1.png" alt="Twitter"></a>
                <a href="https://www.instagram.com" target="_blank"><img src="images/footer/Icon-2.png" alt="Instagram"></a>
                <a href="https://www.pinterest.com" target="_blank"><img src="images/footer/Icon-3.png" alt="Pinterest"></a>
            </div>
        </div>
        <div class="footer-section">
            <h3>Quick Links</h3>
            <ul>
                <li><a href="http://localhost/site/home.php">Home</a></li>
                <li><a href="http://localhost/site/dietplan.php">Dietplan</a></li>
                <li><a href="http://localhost/site/user.php">Account</a></li>
            </ul>
        </div>
        <div class="footer-section">
            <h3>Contact Us</h3>
            <p>Email: support@dietcompanion.com</p>
            <p>Address: 123 Healthy Way, Wellness City, Fitland</p>
            <p>Phone: (123) 456-7890</p>
        </div>
    </footer>
<!--------------------FOOOTER--------------------------------->

</body>
</html>
