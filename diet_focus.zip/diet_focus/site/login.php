<?php
session_start();
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    if ($stmt = $conn->prepare("SELECT UserID, Name, Password FROM userinformation WHERE email = ?")) {
        $stmt->bind_param("s", $email);

        $stmt->execute();

        $stmt->bind_result($userID, $name, $hashed_password);

        if ($stmt->fetch()) {
            if (password_verify($password, $hashed_password)) {
                $_SESSION['userID'] = $userID;
                $_SESSION['name'] = $name;
                $_SESSION['email'] = $email;
                echo "Login successful! Redirecting to your profile.";
                header("Location: user.php");
                exit();
            } else {
                echo "Invalid email or password.";
            }
        } else {
            echo "Invalid email or password.";
        }

        $stmt->close();
    } else {
        echo "Failed to prepare the SQL statement.";
    }

    $conn->close();
} else {
    echo "Invalid request method.";
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="register.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300&family=Kodchasan:wght@300;500&display=swap" rel="stylesheet">
    <title>Registration form</title>
</head>
<body>
<!----------------------------------HEADER BEGINING------------------------------------->
<header>
        <div class="logo"><img src="images/header/acetone-2024521-111521-736 1 (1).png"></div>
        <div class="hamburger">
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
        </div>
        <nav class="nav-bar">
            <ul>
                <li class="button-1">
                    <a href="dietplan.php">Diet</a>
                </li>
                <li class="button-2">
                    <a href="home.php" >Exersice</a>
                </li>
                <li class="button-3">
                    <a href="home.php">Gym</a>
                </li>
                <li class="button-4">
                    <a href="user.php">Profile</a>
                </li>
            </ul>
        </nav>
    </header>
    <script>
        hamburger = document.querySelector(".hamburger");
        hamburger.onclick = function() {
            navBar = document.querySelector(".nav-bar");
            navBar.classList.toggle("active");
        }
    </script>
<!----------------------------------HEADER END------------------------------------->

<div class="container">
    <div class="login-form">
        <h1>Log In</h1>
        <form action="login.php" method="POST">
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <input type="submit" value="Log In">
        </form>
        <p>Don’t have an account? <a href="#signup" class="sign-up">Sign Up here!</a></p>
    </div>
</div>

<!--------------------FOOOTER--------------------------------->
<footer>
        <div class="dividerline">
        </div>
        <div class="footer-section">
            <img src="images/footer/logo.png" alt="Logo" class="footer-logo">
            <p>Your Ultimate Diet Companion is dedicated to helping you achieve your health and wellness goals through personalized meal plans and expert advice.</p>
            <div class="social-media">
                <a href="https://www.facebook.com" target="_blank"><img src="images/footer/Icon.png" alt="Facebook"></a>
                <a href="https://www.twitter.com" target="_blank"><img src="images/footer/Icon-1.png" alt="Twitter"></a>
                <a href="https://www.instagram.com" target="_blank"><img src="images/footer/Icon-2.png" alt="Instagram"></a>
                <a href="https://www.pinterest.com" target="_blank"><img src="images/footer/Icon-3.png" alt="Pinterest"></a>
            </div>
        </div>
        <div class="footer-section">
            <h3>Quick Links</h3>
            <ul>
                <li><a href="http://localhost/site/home.php">Home</a></li>
                <li><a href="http://localhost/site/dietplan.php">Dietplan</a></li>
                <li><a href="http://localhost/site/user.php">Account</a></li>
            </ul>
        </div>
        <div class="footer-section">
            <h3>Contact Us</h3>
            <p>Email: support@dietcompanion.com</p>
            <p>Address: 123 Healthy Way, Wellness City, Fitland</p>
            <p>Phone: (123) 456-7890</p>
        </div>
    </footer>
<!--------------------FOOOTER--------------------------------->

</body>
</html>
